[Book Crossing](http://www2.informatik.uni-freiburg.de/~cziegler/BX/)是一个书籍推荐系统数据，用以向用户推荐偏好的书籍。

